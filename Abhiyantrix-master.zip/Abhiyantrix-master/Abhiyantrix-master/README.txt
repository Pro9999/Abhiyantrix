# Abhiyantrix
Donot make changes to backend just do gui.
While sending pull request just add your name to it.
Everytime there is a new update to this repo just make sure you update your's repo too.
Have a backup of your changes and then only update.
Give a good description of changes to your pull request and be sure you do not make any damn changes to backend.
I have provided a sql of database of our project be sure to add it.
Please read the readme file provided in project too.
